package com.example.cms_campusmanagementsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Signup_Form extends AppCompatActivity {

    EditText txtFullName, txtUserName, txtEmail, txtMobileNumber, txtAddress,
            txtBloodGroup, txtPassword;
    Button btnRegister;
    RadioButton radioGenderMale, radioGenderFemale;
    DatabaseReference databaseReference;
    String gender = "";
    FirebaseAuth firebaseAuth;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup__form);
        getSupportActionBar() .setTitle("Sing up From");


        txtFullName = (EditText) findViewById(R.id.txt_full_name);
        txtUserName = (EditText) findViewById(R.id.txt_user_name);
        txtEmail = (EditText) findViewById(R.id.txt_email);
        txtMobileNumber = (EditText) findViewById(R.id.txt_mobile_number);
        txtAddress = (EditText) findViewById(R.id.txt_address);
        txtBloodGroup = (EditText) findViewById(R.id.txt_blood_group);
        txtPassword = (EditText) findViewById(R.id.txt_password);
        radioGenderMale = (RadioButton) findViewById(R.id.radio_male);
        radioGenderFemale = (RadioButton) findViewById(R.id.radio_female);

        databaseReference =FirebaseDatabase.getInstance().getReference("Student");
        firebaseAuth = FirebaseAuth.getInstance();

        try {
            btnRegister.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View v){

                    final String fullName = txtFullName.getText().toString().trim();
                    final String userName = txtUserName.getText().toString().trim();
                    final String email = txtEmail.getText().toString().trim();
                    final String mobileNumber = txtMobileNumber.getText().toString().trim();
                    final String address = txtAddress.getText().toString().trim();
                    final String bloodGroup = txtBloodGroup.getText().toString().trim();
                    String password = txtPassword.getText().toString().trim();

                    if(radioGenderMale.isChecked()){
                        gender = "Male";

                    }
                    if(radioGenderFemale.isChecked()){
                        gender = "Female";

                    }

                    if(TextUtils.isEmpty(fullName)){
                        Toast.makeText(Signup_Form.this, "Please Enter Full Name", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(TextUtils.isEmpty(userName)){
                        Toast.makeText(Signup_Form.this, "Please Enter User Name", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(TextUtils.isEmpty(email)){
                        Toast.makeText(Signup_Form.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(TextUtils.isEmpty(mobileNumber)){
                        Toast.makeText(Signup_Form.this, "Please Enter Mobile Number", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if(TextUtils.isEmpty(address)){
                        Toast.makeText(Signup_Form.this, "Please Enter Address", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(TextUtils.isEmpty(bloodGroup)){
                        Toast.makeText(Signup_Form.this, "Please Enter Blood Group", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if(TextUtils.isEmpty(password )){
                        Toast.makeText(Signup_Form.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if(password.length()<6){
                        Toast.makeText(Signup_Form.this, "Password Too Short", Toast.LENGTH_SHORT).show();

                    }

                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener( Signup_Form.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {

                                    if (task.isSuccessful()) {

                                        Student information = new Student(

                                                fullName,
                                                userName,
                                                email,
                                                mobileNumber,
                                                address,
                                                bloodGroup,
                                                gender

                                        );

                                        FirebaseDatabase.getInstance().getReference("Student")
                                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .setValue(information).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                Toast.makeText(Signup_Form.this, "Registration Successful ", Toast.LENGTH_SHORT).show();
                                                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                                            }
                                        });

                                    }

                                }

                            });
                }



            });
        }
        catch (NullPointerException ignored){

        }


    }

    public void btn_registration(View view) {

        Toast.makeText(Signup_Form.this, "Registration Successful ", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(),MainActivity.class));
    }
}



































