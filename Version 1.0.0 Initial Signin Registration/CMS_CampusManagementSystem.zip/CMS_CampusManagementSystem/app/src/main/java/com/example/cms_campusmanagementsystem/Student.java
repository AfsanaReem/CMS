package com.example.cms_campusmanagementsystem;

public class Student {
    public String FullName, UserName, Email, MobileNumber, Address, BloodGroup, Gender;

    public Student(){

    }

    public Student(String fullName, String userName, String email, String mobileNumber, String address, String bloodGroup, String gender) {
        FullName = fullName;
        UserName = userName;
        Email = email;
        MobileNumber = mobileNumber;
        Address = address;
        BloodGroup = bloodGroup;
        Gender = gender;
    }
}
